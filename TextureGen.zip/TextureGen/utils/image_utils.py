# TextureGen - Diffuse to PBR Map Generator
# utils/image_utils.py - Image processing utilities
# Created by TLD_Production

import cv2
import numpy as np

def resize_image(image, width, height):
    """Resize an image to the specified dimensions"""
    return cv2.resize(image, (width, height), interpolation=cv2.INTER_LANCZOS4)

def ensure_rgb(image):
    """Ensure an image is in RGB format"""
    if len(image.shape) == 2:
        # Convert grayscale to RGB
        return cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    elif image.shape[2] == 3:
        # Already RGB, return as is
        return image
    elif image.shape[2] == 4:
        # Convert RGBA to RGB
        return cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
    else:
        raise ValueError(f"Unsupported image format with {image.shape[2]} channels")

def ensure_grayscale(image):
    """Ensure an image is in grayscale format"""
    if len(image.shape) == 2:
        # Already grayscale, return as is
        return image
    else:
        # Convert to grayscale
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

def normalize_image(image):
    """Normalize an image to the range [0, 255]"""
    # Get min and max values
    min_val = np.min(image)
    max_val = np.max(image)
    
    # Avoid division by zero
    if max_val == min_val:
        return np.zeros_like(image, dtype=np.uint8)
    
    # Normalize to [0, 255]
    normalized = ((image - min_val) * 255 / (max_val - min_val)).astype(np.uint8)
    
    return normalized