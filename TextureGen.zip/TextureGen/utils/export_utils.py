# TextureGen - Diffuse to PBR Map Generator
# utils/export_utils.py - File export utilities
# Created by TLD_Production

import os
import cv2

def export_png(image, file_path):
    """Export an image as a PNG file"""
    # Ensure directory exists
    directory = os.path.dirname(file_path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)
    
    # Convert from RGB to BGR if needed (OpenCV uses BGR)
    if len(image.shape) == 3 and image.shape[2] == 3:
        save_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    else:
        save_image = image
    
    # Save the image
    cv2.imwrite(file_path, save_image)

def export_texture_set(texture_maps, base_path, format='png'):
    """Export a complete texture set"""
    # File extension
    ext = '.' + format.lower()
    
    # Ensure directory exists
    directory = os.path.dirname(base_path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)
    
    # Export each map with appropriate suffix
    map_suffixes = {
        'diffuse': '_diffuse',
        'normal_map': '_normal',
        'ao_map': '_ao',
        'metallic_map': '_metallic',
        'roughness_map': '_roughness',
        'height_map': '_height'
    }
    
    for map_type, suffix in map_suffixes.items():
        if map_type in texture_maps and texture_maps[map_type] is not None:
            file_path = base_path + suffix + ext
            export_png(texture_maps[map_type], file_path)