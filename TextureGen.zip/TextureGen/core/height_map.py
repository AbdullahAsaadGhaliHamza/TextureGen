# TextureGen - Diffuse to PBR Map Generator
# core/height_map.py - Height map generation
# Created by TLD_Production

import cv2
import numpy as np

def generate_height_map(diffuse_texture, strength=1.0, from_luminance=True):
    """Generate a height/displacement map from a diffuse texture
    
    Args:
        diffuse_texture (numpy.ndarray): The diffuse texture (RGB)
        strength (float): The strength of the height effect (0.1-5.0)
        from_luminance (bool): Whether to generate from luminance or edge detection
        
    Returns:
        numpy.ndarray: The generated height map (grayscale)
    """
    # Convert to grayscale if it's an RGB image
    if len(diffuse_texture.shape) == 3:
        grayscale = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
    else:
        grayscale = diffuse_texture.copy()
    
    if from_luminance:
        # Generate height from luminance (brighter areas = higher)
        height_map = grayscale.copy()
        
        # Apply contrast enhancement for better detail
        # Calculate histogram
        hist = cv2.calcHist([height_map], [0], None, [256], [0, 256])
        
        # Find low and high percentile values for contrast stretching
        cumulative_hist = np.cumsum(hist) / np.sum(hist)
        low_percentile = np.argmax(cumulative_hist > 0.02)
        high_percentile = np.argmax(cumulative_hist > 0.98)
        
        # Apply contrast stretching
        height_map = np.clip((height_map - low_percentile) * 255 / (high_percentile - low_percentile), 0, 255).astype(np.uint8)
        
    else:
        # Generate height from edge detection (more sophisticated approach)
        # First, detect edges
        edges = cv2.Canny(grayscale, 50, 150)
        
        # Invert edges (edges are typically lower in height)
        edges_inverted = 255 - edges
        
        # Use distance transform to create a gradient from edges
        distance = cv2.distanceTransform(edges_inverted, cv2.DIST_L2, 3)
        
        # Normalize distance to 0-255 range
        distance_norm = cv2.normalize(distance, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
        
        # Combine with original grayscale for details
        height_map = cv2.addWeighted(grayscale, 0.7, distance_norm, 0.3, 0)
    
    # Apply bilateral filter to preserve edges while smoothing
    height_map = cv2.bilateralFilter(height_map, 9, 75, 75)
    
    # Apply strength adjustment
    if strength != 1.0:
        # Adjust contrast
        height_map = np.clip(((height_map.astype(float) - 128) * strength) + 128, 0, 255).astype(np.uint8)
    
    return height_map