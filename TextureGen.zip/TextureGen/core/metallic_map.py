# TextureGen - Diffuse to PBR Map Generator
# core/metallic_map.py - Metallic map generation
# Created by TLD_Production

import cv2
import numpy as np

def generate_metallic_map(diffuse_texture, threshold=0.5, method="Brightness"):
    """Generate a metallic map from a diffuse texture
    
    Args:
        diffuse_texture (numpy.ndarray): The diffuse texture (RGB)
        threshold (float): The threshold value for metal detection (0.0-1.0)
        method (str): The method to use for metal detection:
                     "Brightness" - based on pixel brightness
                     "Color" - based on metal-like colors
                     "Pattern Recognition" - using pattern analysis
        
    Returns:
        numpy.ndarray: The generated metallic map (grayscale)
    """
    # Create an empty metallic map
    if len(diffuse_texture.shape) == 3:
        height, width, _ = diffuse_texture.shape
    else:
        height, width = diffuse_texture.shape
        
    metallic_map = np.zeros((height, width), dtype=np.uint8)
    
    if method == "Brightness":
        # Convert to grayscale
        if len(diffuse_texture.shape) == 3:
            grayscale = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
        else:
            grayscale = diffuse_texture.copy()
        
        # Calculate metallic areas based on brightness and threshold
        # Typically shinier/more reflective areas could be metallic
        metallic_map = np.where(
            grayscale > (threshold * 255),
            255,  # Metallic (white)
            0     # Non-metallic (black)
        ).astype(np.uint8)
        
        # Apply a slight blur to reduce noise
        metallic_map = cv2.GaussianBlur(metallic_map, (3, 3), 0)
        
    elif method == "Color":
        # Check for metal-like colors (grays, silvers, golds)
        if len(diffuse_texture.shape) == 3:
            # Convert to HSV for better color analysis
            hsv = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2HSV)
            
            # Extract channels
            hue = hsv[:, :, 0]
            saturation = hsv[:, :, 1]
            value = hsv[:, :, 2]
            
            # Metal detection parameters
            # 1. Gray metals: low saturation, medium to high value
            gray_metals = (saturation < 50) & (value > 100)
            
            # 2. Gold/copper: yellowish/orange hue, medium saturation, high value
            gold_metals = ((hue > 20) & (hue < 40)) & (saturation > 100) & (value > 200)
            
            # 3. Chrome/silver: very low saturation, very high value
            chrome_metals = (saturation < 20) & (value > 200)
            
            # Combine all metal types
            metallic_map = np.where(
                gray_metals | gold_metals | chrome_metals,
                255,  # Metallic (white)
                0     # Non-metallic (black)
            ).astype(np.uint8)
            
            # Apply threshold to control sensitivity
            _, metallic_map = cv2.threshold(
                metallic_map,
                int(threshold * 255),
                255,
                cv2.THRESH_BINARY
            )
            
        else:
            # For grayscale, we can only use brightness
            metallic_map = np.where(
                diffuse_texture > (threshold * 255),
                255,  # Metallic (white)
                0     # Non-metallic (black)
            ).astype(np.uint8)
    
    elif method == "Pattern Recognition":
        # Simplified version using edge detection
        if len(diffuse_texture.shape) == 3:
            grayscale = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
        else:
            grayscale = diffuse_texture.copy()
        
        # Detect edges using Canny
        edges = cv2.Canny(grayscale, 50, 150)
        
        # Calculate edge density (metals have fewer edges)
        kernel_size = 15
        kernel = np.ones((kernel_size, kernel_size), np.float32) / (kernel_size * kernel_size)
        edge_density = cv2.filter2D(edges.astype(np.float32), -1, kernel)
        
        # Invert density (less edges = more likely to be metal)
        inverse_density = 255 - edge_density
        
        # Apply threshold
        metallic_map = np.where(
            inverse_density > (255 * threshold),
            255,
            0
        ).astype(np.uint8)
        
        # Remove small noise
        kernel = np.ones((3, 3), np.uint8)
        metallic_map = cv2.morphologyEx(metallic_map, cv2.MORPH_OPEN, kernel)
        metallic_map = cv2.morphologyEx(metallic_map, cv2.MORPH_CLOSE, kernel)
    
    # Apply final smoothing
    metallic_map = cv2.GaussianBlur(metallic_map, (5, 5), 0)
    
    return metallic_map