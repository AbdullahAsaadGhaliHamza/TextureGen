# TextureGen - Diffuse to PBR Map Generator
# core/roughness_map.py - Roughness map generation
# Created by TLD_Production

import cv2
import numpy as np

def generate_roughness_map(diffuse_texture, height_map=None, base_level=0.5, from_detail=True, invert=False):
    """Generate a roughness map from a diffuse texture and optional height map
    
    Args:
        diffuse_texture (numpy.ndarray): The diffuse texture (RGB)
        height_map (numpy.ndarray, optional): The height map (grayscale)
        base_level (float): The base roughness level (0.0-1.0)
        from_detail (bool): Whether to generate roughness from surface detail
        invert (bool): Whether to invert the roughness (bright = smooth)
        
    Returns:
        numpy.ndarray: The generated roughness map (grayscale)
    """
    # Create a base roughness map with the specified level
    if len(diffuse_texture.shape) == 3:
        height, width, _ = diffuse_texture.shape
    else:
        height, width = diffuse_texture.shape
    
    # Start with the base roughness level
    roughness_map = np.ones((height, width), dtype=np.uint8) * int(base_level * 255)
    
    if from_detail:
        # Generate roughness from surface detail
        if height_map is not None and len(height_map.shape) == 2:
            # Use the height map for detail information
            detail_map = height_map.copy()
        else:
            # Convert diffuse to grayscale
            if len(diffuse_texture.shape) == 3:
                detail_map = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
            else:
                detail_map = diffuse_texture.copy()
        
        # Calculate local variance (higher variance = rougher surface)
        kernel_size = 5
        mean = cv2.blur(detail_map, (kernel_size, kernel_size))
        mean_sq = cv2.blur(detail_map * detail_map, (kernel_size, kernel_size))
        variance = mean_sq - mean * mean
        
        # Normalize the variance to a reasonable range
        variance_normalized = np.clip(variance * 0.1, 0, 255).astype(np.uint8)
        
        # Combine base roughness with detail-based roughness
        roughness_map = cv2.addWeighted(
            roughness_map, 0.7,
            variance_normalized, 0.3,
            0
        )
        
        # Apply edge detection for additional detail
        edges = cv2.Canny(detail_map, 50, 150)
        # Dilate edges slightly to affect surrounding areas
        kernel = np.ones((3, 3), np.uint8)
        edges_dilated = cv2.dilate(edges, kernel, iterations=1)
        
        # Add edges to roughness (edges are typically rougher)
        roughness_map = np.maximum(roughness_map, edges_dilated)
        
        # Smooth the result
        roughness_map = cv2.GaussianBlur(roughness_map, (3, 3), 0)
    
    # Invert if requested (in PBR, sometimes white = smooth, black = rough)
    if invert:
        roughness_map = 255 - roughness_map
    
    return roughness_map