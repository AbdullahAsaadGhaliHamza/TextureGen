# TextureGen - Diffuse to PBR Map Generator
# core/normal_map.py - Normal map generation
# Created by TLD_Production

import cv2
import numpy as np

def generate_normal_map(diffuse_texture, strength=1.0, detail_scale=20, invert_y=True):
    """Generate a normal map from a diffuse texture
    
    Args:
        diffuse_texture (numpy.ndarray): The diffuse texture (RGB)
        strength (float): The strength of the normal map effect (0.1-10.0)
        detail_scale (int): The scale of details to extract (1-100)
        invert_y (bool): Whether to invert the Y component (DirectX style)
        
    Returns:
        numpy.ndarray: The generated normal map (RGB)
    """
    # Convert to grayscale for height calculation
    if len(diffuse_texture.shape) == 3:
        grayscale = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
    else:
        grayscale = diffuse_texture.copy()
    
    # Apply Gaussian blur to control detail level
    blur_size = max(1, int((101 - detail_scale) / 5))
    if blur_size % 2 == 0:
        blur_size += 1  # Ensure odd kernel size
    
    blurred = cv2.GaussianBlur(grayscale, (blur_size, blur_size), 0)
    
    # Calculate gradients using Sobel operators
    scale_factor = float(strength) * 0.1
    dx = cv2.Sobel(blurred, cv2.CV_32F, 1, 0, ksize=3) * scale_factor
    dy = cv2.Sobel(blurred, cv2.CV_32F, 0, 1, ksize=3) * scale_factor
    
    # If DirectX style normals are requested, invert Y component
    if invert_y:
        dy = -dy
    
    # Calculate the Z component (constant for now)
    dz = np.ones_like(dx) * 128  # Middle value (flat surface)
    
    # Create an empty array for the normal map (RGB)
    height, width = grayscale.shape
    normal_map = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Convert the gradient values to the normal map color range (0-255)
    normal_map[:, :, 0] = np.clip(dx + 128, 0, 255).astype(np.uint8)  # R = X
    normal_map[:, :, 1] = np.clip(dy + 128, 0, 255).astype(np.uint8)  # G = Y
    normal_map[:, :, 2] = dz.astype(np.uint8)  # B = Z
    
    return normal_map