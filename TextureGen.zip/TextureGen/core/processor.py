# TextureGen - Diffuse to PBR Map Generator
# core/processor.py - Main processing pipeline
# Created by TLD_Production

import os
import cv2
import numpy as np

# Import processing modules
from core.normal_map import generate_normal_map
from core.ao_map import generate_ao_map
from core.metallic_map import generate_metallic_map
from core.roughness_map import generate_roughness_map
from core.height_map import generate_height_map

class TextureProcessor:
    def __init__(self):
        # Cache for processed maps
        self.processed_maps = {
            'normal_map': None,
            'ao_map': None,
            'metallic_map': None,
            'roughness_map': None,
            'height_map': None
        }
        
        # Source texture
        self.source_texture = None
        self.source_path = None
        
    def process_texture(self, texture_path, settings):
        """Process a diffuse texture to generate all PBR maps"""
        # Load the texture
        self.source_path = texture_path
        self.source_texture = cv2.imread(texture_path)
        
        if self.source_texture is None:
            raise ValueError(f"Failed to load texture: {texture_path}")
        
        # Convert from BGR to RGB (OpenCV loads as BGR)
        self.source_texture = cv2.cvtColor(self.source_texture, cv2.COLOR_BGR2RGB)
        
        # Generate height map first (needed for other maps)
        height_map = generate_height_map(
            self.source_texture,
            strength=settings['height_strength'],
            from_luminance=settings['height_from_luminance']
        )
        
        # Generate normal map
        normal_map = generate_normal_map(
            self.source_texture, 
            strength=settings['normal_strength'],
            detail_scale=settings['normal_detail'],
            invert_y=settings['normal_invert_y']
        )
        
        # Generate AO map
        ao_map = generate_ao_map(
            self.source_texture,
            height_map,
            strength=settings['ao_strength'],
            radius=settings['ao_radius']
        )
        
        # Generate metallic map
        metallic_map = generate_metallic_map(
            self.source_texture,
            threshold=settings['metallic_threshold'],
            method=settings['metal_detect_method']
        )
        
        # Generate roughness map
        roughness_map = generate_roughness_map(
            self.source_texture,
            height_map,
            base_level=settings['roughness_base'],
            from_detail=settings['roughness_from_detail'],
            invert=settings['roughness_invert']
        )
        
        # Store generated maps
        self.processed_maps = {
            'normal_map': normal_map,
            'ao_map': ao_map,
            'metallic_map': metallic_map,
            'roughness_map': roughness_map,
            'height_map': height_map
        }
        
        return self.processed_maps
    
    def export_all_maps(self, export_dir, base_name):
        """Export all generated maps to the specified directory"""
        if not os.path.exists(export_dir):
            os.makedirs(export_dir)
            
        # Export each map
        for map_type, map_data in self.processed_maps.items():
            if map_data is not None:
                file_path = os.path.join(export_dir, f"{base_name}_{map_type}.png")
                self.export_map(map_type, file_path)
    
    def export_map(self, map_type, file_path):
        """Export a specific map to the specified file path"""
        if map_type not in self.processed_maps or self.processed_maps[map_type] is None:
            raise ValueError(f"No {map_type} has been generated yet")
            
        # Get the map data
        map_data = self.processed_maps[map_type]
        
        # Convert to the correct format for saving
        if map_type == 'normal_map':
            # Normal maps are RGB
            save_data = cv2.cvtColor(map_data, cv2.COLOR_RGB2BGR)
        else:
            # Other maps are typically grayscale
            if len(map_data.shape) == 3:
                save_data = cv2.cvtColor(map_data, cv2.COLOR_RGB2BGR)
            else:
                save_data = map_data
        
        # Save the image
        cv2.imwrite(file_path, save_data)