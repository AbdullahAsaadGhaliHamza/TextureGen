# TextureGen - Diffuse to PBR Map Generator
# core/ao_map.py - Ambient occlusion map generation
# Created by TLD_Production

import cv2
import numpy as np

def generate_ao_map(diffuse_texture, height_map=None, strength=1.0, radius=16):
    """Generate an ambient occlusion map from a diffuse texture and/or height map
    
    Args:
        diffuse_texture (numpy.ndarray): The diffuse texture (RGB)
        height_map (numpy.ndarray, optional): The height map (grayscale)
        strength (float): The strength of the AO effect (0.1-5.0)
        radius (int): The radius to consider for AO calculation (1-100)
        
    Returns:
        numpy.ndarray: The generated ambient occlusion map (grayscale)
    """
    # If a height map is provided, use it; otherwise generate from diffuse
    if height_map is not None and len(height_map.shape) == 2:
        height = height_map.copy()
    else:
        # Convert to grayscale for height calculation
        if len(diffuse_texture.shape) == 3:
            height = cv2.cvtColor(diffuse_texture, cv2.COLOR_RGB2GRAY)
        else:
            height = diffuse_texture.copy()
    
    # Scale the radius based on the image size
    height_pixels, width_pixels = height.shape
    scaled_radius = max(1, int(min(height_pixels, width_pixels) * radius / 500))
    
    # Simple AO approximation: darker areas where height changes rapidly
    grad_x = cv2.Sobel(height, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(height, cv2.CV_32F, 0, 1, ksize=3)
    
    # Calculate gradient magnitude
    gradient = cv2.magnitude(grad_x, grad_y)
    
    # Normalize and adjust strength
    gradient = gradient * strength
    gradient = cv2.normalize(gradient, None, 0, 255, cv2.NORM_MINMAX)
    
    # Convert to AO (invert - higher gradient = more occlusion = darker)
    ao_map = 255 - gradient.astype(np.uint8)
    
    # Apply Gaussian blur for smoother result
    ao_map = cv2.GaussianBlur(ao_map, (2*scaled_radius+1, 2*scaled_radius+1), 0)
    
    return ao_map