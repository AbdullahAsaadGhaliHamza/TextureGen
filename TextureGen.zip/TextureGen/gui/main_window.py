# TextureGen - Diffuse to PBR Map Generator
# gui/main_window.py - Main application window
# Created by TLD_Production

import os
import sys
from PyQt5.QtWidgets import (QMainWindow, QAction, QFileDialog, QWidget, 
                            QHBoxLayout, QSplitter, QMessageBox)
from PyQt5.QtCore import Qt, QSettings
from PyQt5.QtGui import QIcon

from gui.preview_widget import TexturePreviewWidget
from gui.settings_panel import SettingsPanel
from core.processor import TextureProcessor

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # Create the processor first
        self.texture_processor = TextureProcessor()
        self.current_diffuse_path = None
        self.settings = QSettings("TLD_Production", "TextureGen")
        
        # Initialize UI
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the user interface"""
        self.setWindowTitle("TextureGen - Diffuse to PBR Map Generator")
        self.setMinimumSize(1200, 800)
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Create main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(splitter)
        
        # Left panel - Preview widget
        self.preview_widget = TexturePreviewWidget()
        splitter.addWidget(self.preview_widget)
        
        # Right panel - Settings panel
        self.settings_panel = SettingsPanel(self.texture_processor)
        self.settings_panel.settingsChanged.connect(self.process_texture)
        self.settings_panel.setMinimumWidth(300)
        self.settings_panel.setMaximumWidth(400)
        splitter.addWidget(self.settings_panel)
        
        # Set splitter sizes
        splitter.setSizes([800, 400])
        
        # Create menus
        self.create_menus()
        
        # Set up status bar
        self.statusBar().showMessage("Ready")
        
        # Enable drag and drop
        self.setAcceptDrops(True)
        
    def create_menus(self):
        """Create application menus"""
        # File menu
        file_menu = self.menuBar().addMenu("&File")
        
        # Open action
        open_action = QAction("&Open Diffuse Texture...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_diffuse_dialog)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        # Export action
        export_action = QAction("&Export All Maps...", self)
        export_action.setShortcut("Ctrl+E")
        export_action.triggered.connect(self.export_all_maps)
        file_menu.addAction(export_action)
        
        file_menu.addSeparator()
        
        # Exit action
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = self.menuBar().addMenu("&Edit")
        
        # Process action
        process_action = QAction("&Process Texture", self)
        process_action.setShortcut("Ctrl+P")
        process_action.triggered.connect(self.process_texture)
        edit_menu.addAction(process_action)
        
        # Help menu
        help_menu = self.menuBar().addMenu("&Help")
        
        # About action
        about_action = QAction("&About TextureGen", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def open_diffuse_dialog(self):
        """Open a file dialog to select a diffuse texture"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Diffuse Texture",
            "",
            "Image Files (*.png *.jpg *.jpeg *.bmp *.tga);;All Files (*)"
        )
        
        if file_path:
            self.open_diffuse(file_path)
            
    def open_diffuse(self, file_path):
        """Open a diffuse texture file"""
        if not os.path.exists(file_path):
            QMessageBox.critical(self, "Error", f"File not found: {file_path}")
            return
            
        try:
            self.current_diffuse_path = file_path
            self.statusBar().showMessage(f"Loaded: {os.path.basename(file_path)}")
            
            # Update window title
            self.setWindowTitle(f"TextureGen - {os.path.basename(file_path)}")
            
            # Load and display the diffuse texture
            self.preview_widget.set_diffuse_texture(file_path)
            
            # Process the texture to generate maps
            self.process_texture()
            
        except Exception as e:
            self.statusBar().showMessage(f"Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to open texture: {str(e)}")
            
    def process_texture(self):
        """Process the loaded diffuse texture to generate PBR maps"""
        if not self.current_diffuse_path:
            QMessageBox.warning(self, "Warning", "No texture loaded. Please open a texture first.")
            return
            
        self.statusBar().showMessage("Processing texture...")
        
        # Get settings from the panel
        settings = self.settings_panel.get_settings()
        
        # Process the texture
        try:
            results = self.texture_processor.process_texture(
                self.current_diffuse_path, 
                settings
            )
            
            # Update the preview with the generated maps
            self.preview_widget.set_normal_map(results['normal_map'])
            self.preview_widget.set_ao_map(results['ao_map'])
            self.preview_widget.set_metallic_map(results['metallic_map'])
            self.preview_widget.set_roughness_map(results['roughness_map'])
            self.preview_widget.set_height_map(results['height_map'])
            
            self.statusBar().showMessage("Processing complete")
        except Exception as e:
            self.statusBar().showMessage(f"Error: {str(e)}")
            QMessageBox.critical(self, "Processing Error", str(e))
    
    def export_all_maps(self):
        """Export all generated maps"""
        if not self.current_diffuse_path:
            QMessageBox.warning(self, "Warning", "No texture loaded. Please open a texture first.")
            return
            
        export_dir = QFileDialog.getExistingDirectory(
            self, 
            "Select Export Directory"
        )
        
        if export_dir:
            try:
                base_name = os.path.splitext(os.path.basename(self.current_diffuse_path))[0]
                self.texture_processor.export_all_maps(export_dir, base_name)
                self.statusBar().showMessage(f"Exported all maps to {export_dir}")
                
                # Ask if user wants to open the export directory
                reply = QMessageBox.question(
                    self,
                    "Export Complete",
                    f"All maps have been exported to:\n{export_dir}\n\nWould you like to open this folder?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No
                )
                
                if reply == QMessageBox.Yes:
                    self.open_directory(export_dir)
                    
            except Exception as e:
                QMessageBox.critical(self, "Export Error", str(e))
    
    def open_directory(self, path):
        """Open a directory in the system file explorer"""
        if sys.platform == 'win32':
            os.startfile(path)
        elif sys.platform == 'darwin':  # macOS
            os.system(f'open "{path}"')
        else:  # Linux
            os.system(f'xdg-open "{path}"')
    
    def show_about(self):
        """Show the about dialog"""
        QMessageBox.about(
            self,
            "About TextureGen",
            "<h1>TextureGen</h1>"
            "<p>Version 0.1.0</p>"
            "<p>A tool for generating PBR texture maps from diffuse textures.</p>"
            "<p>Create complete PBR material sets quickly and efficiently.</p>"
            "<p>&copy; 2025 TLD_Production</p>"
        )
        
    def dragEnterEvent(self, event):
        """Handle drag enter events for drag & drop"""
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.isLocalFile():
                    file_path = url.toLocalFile()
                    ext = os.path.splitext(file_path)[1].lower()
                    if ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga']:
                        event.acceptProposedAction()
                        return
        event.ignore()
    
    def dropEvent(self, event):
        """Handle drop events for drag & drop"""
        for url in event.mimeData().urls():
            if url.isLocalFile():
                file_path = url.toLocalFile()
                ext = os.path.splitext(file_path)[1].lower()
                if ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga']:
                    self.open_diffuse(file_path)
                    break