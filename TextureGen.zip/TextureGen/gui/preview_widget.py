# TextureGen - Diffuse to PBR Map Generator
# gui/preview_widget.py - Texture preview widget
# Created by TLD_Production

import os
import numpy as np
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                            QComboBox, QScrollArea, QSizePolicy)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QImage

class TexturePreviewWidget(QWidget):
    def __init__(self):
        super().__init__()
        
        # Store the textures
        self.textures = {
            'diffuse': None,
            'normal_map': None,
            'ao_map': None,
            'metallic_map': None,
            'roughness_map': None,
            'height_map': None
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the user interface"""
        main_layout = QVBoxLayout(self)
        
        # Texture type selector
        selector_layout = QHBoxLayout()
        selector_layout.addWidget(QLabel("Display:"))
        
        self.texture_selector = QComboBox()
        self.texture_selector.addItems([
            "Diffuse Texture",
            "Normal Map",
            "Ambient Occlusion Map",
            "Metallic Map",
            "Roughness Map",
            "Height Map"
        ])
        self.texture_selector.currentIndexChanged.connect(self.update_preview)
        selector_layout.addWidget(self.texture_selector)
        selector_layout.addStretch()
        
        main_layout.addLayout(selector_layout)
        
        # Texture preview
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        
        self.preview_label = QLabel("No texture loaded")
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.preview_label.setScaledContents(True)
        
        scroll_area.setWidget(self.preview_label)
        main_layout.addWidget(scroll_area, 1)
        
        # Info label
        self.info_label = QLabel("No texture loaded")
        main_layout.addWidget(self.info_label)
        
    def set_diffuse_texture(self, texture_path_or_array):
        """Set the diffuse texture to display"""
        self.set_texture('diffuse', texture_path_or_array)
        self.texture_selector.setCurrentIndex(0)  # Switch to diffuse view
        
    def set_normal_map(self, texture_path_or_array):
        """Set the normal map to display"""
        self.set_texture('normal_map', texture_path_or_array)
        
    def set_ao_map(self, texture_path_or_array):
        """Set the ambient occlusion map to display"""
        self.set_texture('ao_map', texture_path_or_array)
        
    def set_metallic_map(self, texture_path_or_array):
        """Set the metallic map to display"""
        self.set_texture('metallic_map', texture_path_or_array)
        
    def set_roughness_map(self, texture_path_or_array):
        """Set the roughness map to display"""
        self.set_texture('roughness_map', texture_path_or_array)
        
    def set_height_map(self, texture_path_or_array):
        """Set the height map to display"""
        self.set_texture('height_map', texture_path_or_array)
        
    def set_texture(self, texture_type, texture_path_or_array):
        """Set a texture from file path or numpy array"""
        if texture_path_or_array is None:
            self.textures[texture_type] = None
            return
            
        if isinstance(texture_path_or_array, str):
            # Load from file path
            if os.path.exists(texture_path_or_array):
                self.textures[texture_type] = QPixmap(texture_path_or_array)
        elif isinstance(texture_path_or_array, np.ndarray):
            # Convert numpy array to QPixmap
            height, width = texture_path_or_array.shape[:2]
            
            # Handle different image formats
            if len(texture_path_or_array.shape) == 2:
                # Grayscale image
                image = QImage(texture_path_or_array.data, width, height, width, QImage.Format_Grayscale8)
            elif texture_path_or_array.shape[2] == 3:
                # RGB image
                bytes_per_line = 3 * width
                image = QImage(texture_path_or_array.data, width, height, bytes_per_line, QImage.Format_RGB888)
            elif texture_path_or_array.shape[2] == 4:
                # RGBA image
                bytes_per_line = 4 * width
                image = QImage(texture_path_or_array.data, width, height, bytes_per_line, QImage.Format_RGBA8888)
            
            self.textures[texture_type] = QPixmap.fromImage(image)
        
        # Update the preview if this is the currently selected texture
        self.update_preview()
        
    def update_preview(self):
        """Update the texture preview based on the selected texture type"""
        texture_index = self.texture_selector.currentIndex()
        texture_types = ['diffuse', 'normal_map', 'ao_map', 'metallic_map', 'roughness_map', 'height_map']
        
        if texture_index >= 0 and texture_index < len(texture_types):
            texture_type = texture_types[texture_index]
            texture = self.textures[texture_type]
            
            if texture:
                self.preview_label.setPixmap(texture)
                
                # Update info label
                size = texture.size()
                self.info_label.setText(f"{texture_type.replace('_', ' ').title()}: {size.width()}x{size.height()}")
            else:
                self.preview_label.setText(f"No {texture_type.replace('_', ' ')} loaded")
                self.info_label.setText("No texture loaded")