# TextureGen - Diffuse to PBR Map Generator
# gui/settings_panel.py - Settings panel for adjusting parameters
# Created by TLD_Production

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QGroupBox,
                           QSlider, QCheckBox, QLabel, QPushButton, QSpinBox,
                           QDoubleSpinBox, QComboBox)
from PyQt5.QtCore import Qt, pyqtSignal

class SettingsPanel(QWidget):
    # Signal emitted when settings are changed
    settingsChanged = pyqtSignal()
    
    def __init__(self, texture_processor):
        super().__init__()
        
        self.texture_processor = texture_processor
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the user interface"""
        main_layout = QVBoxLayout(self)
        
        # Normal Map settings
        normal_group = QGroupBox("Normal Map Settings")
        normal_layout = QFormLayout()
        
        # Normal strength
        self.normal_strength = QDoubleSpinBox()
        self.normal_strength.setRange(0.1, 10.0)
        self.normal_strength.setSingleStep(0.1)
        self.normal_strength.setValue(1.0)
        self.normal_strength.valueChanged.connect(self.on_settings_changed)
        normal_layout.addRow("Strength:", self.normal_strength)
        
        # Normal detail scale
        self.normal_detail = QSpinBox()
        self.normal_detail.setRange(1, 100)
        self.normal_detail.setValue(20)
        self.normal_detail.valueChanged.connect(self.on_settings_changed)
        normal_layout.addRow("Detail Scale:", self.normal_detail)
        
        # Invert normal Y
        self.normal_invert_y = QCheckBox("Invert Y (DirectX)")
        self.normal_invert_y.setChecked(True)
        self.normal_invert_y.stateChanged.connect(self.on_settings_changed)
        normal_layout.addRow("", self.normal_invert_y)
        
        normal_group.setLayout(normal_layout)
        main_layout.addWidget(normal_group)
        
        # Ambient Occlusion settings
        ao_group = QGroupBox("Ambient Occlusion Settings")
        ao_layout = QFormLayout()
        
        # AO strength
        self.ao_strength = QDoubleSpinBox()
        self.ao_strength.setRange(0.1, 5.0)
        self.ao_strength.setSingleStep(0.1)
        self.ao_strength.setValue(1.0)
        self.ao_strength.valueChanged.connect(self.on_settings_changed)
        ao_layout.addRow("Strength:", self.ao_strength)
        
        # AO radius
        self.ao_radius = QSpinBox()
        self.ao_radius.setRange(1, 100)
        self.ao_radius.setValue(16)
        self.ao_radius.valueChanged.connect(self.on_settings_changed)
        ao_layout.addRow("Radius:", self.ao_radius)
        
        ao_group.setLayout(ao_layout)
        main_layout.addWidget(ao_group)
        
        # Metallic Map settings
        metallic_group = QGroupBox("Metallic Map Settings")
        metallic_layout = QFormLayout()
        
        # Metallic threshold
        self.metallic_threshold = QDoubleSpinBox()
        self.metallic_threshold.setRange(0.0, 1.0)
        self.metallic_threshold.setSingleStep(0.05)
        self.metallic_threshold.setValue(0.5)
        self.metallic_threshold.valueChanged.connect(self.on_settings_changed)
        metallic_layout.addRow("Threshold:", self.metallic_threshold)
        
        # Metal detect method
        self.metal_detect_method = QComboBox()
        self.metal_detect_method.addItems(["Brightness", "Color", "Pattern Recognition"])
        self.metal_detect_method.currentIndexChanged.connect(self.on_settings_changed)
        metallic_layout.addRow("Detection Method:", self.metal_detect_method)
        
        metallic_group.setLayout(metallic_layout)
        main_layout.addWidget(metallic_group)
        
        # Roughness Map settings
        roughness_group = QGroupBox("Roughness Map Settings")
        roughness_layout = QFormLayout()
        
        # Roughness base level
        self.roughness_base = QDoubleSpinBox()
        self.roughness_base.setRange(0.0, 1.0)
        self.roughness_base.setSingleStep(0.05)
        self.roughness_base.setValue(0.5)
        self.roughness_base.valueChanged.connect(self.on_settings_changed)
        roughness_layout.addRow("Base Level:", self.roughness_base)
        
        # Roughness from detail
        self.roughness_from_detail = QCheckBox("Generate from Surface Detail")
        self.roughness_from_detail.setChecked(True)
        self.roughness_from_detail.stateChanged.connect(self.on_settings_changed)
        roughness_layout.addRow("", self.roughness_from_detail)
        
        # Invert roughness
        self.roughness_invert = QCheckBox("Invert (Bright = Smooth)")
        self.roughness_invert.setChecked(False)
        self.roughness_invert.stateChanged.connect(self.on_settings_changed)
        roughness_layout.addRow("", self.roughness_invert)
        
        roughness_group.setLayout(roughness_layout)
        main_layout.addWidget(roughness_group)
        
        # Height Map settings
        height_group = QGroupBox("Height Map Settings")
        height_layout = QFormLayout()
        
        # Height strength
        self.height_strength = QDoubleSpinBox()
        self.height_strength.setRange(0.1, 5.0)
        self.height_strength.setSingleStep(0.1)
        self.height_strength.setValue(1.0)
        self.height_strength.valueChanged.connect(self.on_settings_changed)
        height_layout.addRow("Strength:", self.height_strength)
        
        # Height from luminance
        self.height_from_luminance = QCheckBox("Generate from Luminance")
        self.height_from_luminance.setChecked(True)
        self.height_from_luminance.stateChanged.connect(self.on_settings_changed)
        height_layout.addRow("", self.height_from_luminance)
        
        height_group.setLayout(height_layout)
        main_layout.addWidget(height_group)
        
        # Add process button
        self.process_button = QPushButton("Process Texture")
        self.process_button.clicked.connect(self.on_process_clicked)
        main_layout.addWidget(self.process_button)
        
        # Add stretch to push everything to the top
        main_layout.addStretch()
        
    def on_settings_changed(self):
        """Handle settings changes"""
        self.settingsChanged.emit()
        
    def on_process_clicked(self):
        """Handle the process button being clicked"""
        self.settingsChanged.emit()
        
    def get_settings(self):
        """Get the current settings as a dictionary"""
        settings = {
            # Normal map settings
            'normal_strength': self.normal_strength.value(),
            'normal_detail': self.normal_detail.value(),
            'normal_invert_y': self.normal_invert_y.isChecked(),
            
            # AO settings
            'ao_strength': self.ao_strength.value(),
            'ao_radius': self.ao_radius.value(),
            
            # Metallic settings
            'metallic_threshold': self.metallic_threshold.value(),
            'metal_detect_method': self.metal_detect_method.currentText(),
            
            # Roughness settings
            'roughness_base': self.roughness_base.value(),
            'roughness_from_detail': self.roughness_from_detail.isChecked(),
            'roughness_invert': self.roughness_invert.isChecked(),
            
            # Height settings
            'height_strength': self.height_strength.value(),
            'height_from_luminance': self.height_from_luminance.isChecked(),
            
            # Extra settings for compatibility
            'resolution': "Original",
            'detail_level': 0.5
        }
        
        return settings
    
    def reset_settings(self):
        """Reset all settings to their default values"""
        # Normal map settings
        self.normal_strength.setValue(1.0)
        self.normal_detail.setValue(20)
        self.normal_invert_y.setChecked(True)
        
        # AO settings
        self.ao_strength.setValue(1.0)
        self.ao_radius.setValue(16)
        
        # Metallic settings
        self.metallic_threshold.setValue(0.5)
        self.metal_detect_method.setCurrentIndex(0)
        
        # Roughness settings
        self.roughness_base.setValue(0.5)
        self.roughness_from_detail.setChecked(True)
        self.roughness_invert.setChecked(False)
        
        # Height settings
        self.height_strength.setValue(1.0)
        self.height_from_luminance.setChecked(True)
        
        # Emit settings changed signal
        self.settingsChanged.emit()