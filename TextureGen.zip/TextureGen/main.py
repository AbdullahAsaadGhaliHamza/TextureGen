#!/usr/bin/env python3
# TextureGen - Diffuse to PBR Map Generator
# Created by TLD_Production

import sys
import os
import traceback
from PyQt5.QtWidgets import QApplication, QMessageBox, QSplashScreen
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap, QIcon

def get_resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)

def show_error(message):
    """Show an error message box"""
    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)
    
    error_box = QMessageBox()
    error_box.setIcon(QMessageBox.Critical)
    error_box.setWindowTitle("TextureGen Error")
    error_box.setText("An error occurred")
    error_box.setInformativeText(message)
    error_box.setDetailedText(traceback.format_exc())
    error_box.exec_()

def main():
    """Main application entry point"""
    try:
        # Create the application
        app = QApplication(sys.argv)
        app.setApplicationName("TextureGen")
        app.setApplicationVersion("0.1.0")
        app.setOrganizationName("TLD_Production")
        
        # Set application icon
        icon_path = get_resource_path(os.path.join("resources", "icons", "app_icon.ico"))
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
        
        # Show splash screen
        splash_path = get_resource_path(os.path.join("resources", "images", "splash.png"))
        splash = None
        
        if os.path.exists(splash_path):
            splash_pixmap = QPixmap(splash_path)
            splash = QSplashScreen(splash_pixmap, Qt.WindowStaysOnTopHint)
            splash.show()
            app.processEvents()
        else:
            # Create a simple text splash screen
            splash = QSplashScreen(QPixmap(400, 200), Qt.WindowStaysOnTopHint)
            splash.show()
            splash.showMessage("TextureGen by TLD_Production\nLoading...", 
                              Qt.AlignCenter, Qt.white)
            app.processEvents()
        
        # Import the MainWindow class here to show the splash during import
        try:
            from gui.main_window import MainWindow
            window = MainWindow()
            
            # Close splash and show main window after a delay
            def show_main_window():
                splash.finish(window)
                window.show()
            
            QTimer.singleShot(1000, show_main_window)
            
            # Run the application
            return app.exec_()
            
        except ImportError as e:
            if splash:
                splash.close()
            show_error(f"Failed to import application modules: {str(e)}\n\n"
                      "Please make sure all required packages are installed:\n"
                      "pip install numpy scipy opencv-python pillow pyqt5")
            return 1
            
    except Exception as e:
        show_error(f"Application startup error: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())